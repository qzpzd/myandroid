package tech.summerly.quiet.search

import tech.summerly.quiet.commonlib.base.BaseModule

/**
 * Created by summer on 18-2-17
 */
internal object SearchModule : BaseModule() {

}