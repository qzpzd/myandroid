package tech.summerly.quiet.commonlib.player

import android.support.test.runner.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MusicPlayerManagerTest {


    @Test
    fun test() {

    }

}