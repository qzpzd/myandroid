package tech.summerly.quiet.commonlib.model

import java.io.Serializable

interface IAlbum : Serializable {


    fun name(): String

}