package tech.summerly.quiet.commonlib.bean

/**
 * author : SUMMERLY
 * e-mail : yangbinyhbn@gmail.com
 * time   : 2017/8/26
 * desc   :
 */
enum class MusicType  {
    LOCAL,
    NETEASE,
    NETEASE_FM
}