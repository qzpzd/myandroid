package tech.summerly.quiet.commonlib.model

import java.io.Serializable

interface IArtist : Serializable {

    fun name(): String

}