package tech.summerly.quiet.commonlib.player

enum class PlayerType {
    FM,
    NORMAL
}