package tech.summerly.quiet.commonlib.player.core

/**
 * Created by summer on 18-3-4
 */
enum class PlayerState {
    Idle,
    Pausing,
    Playing,
    Preparing,
    Complete
}