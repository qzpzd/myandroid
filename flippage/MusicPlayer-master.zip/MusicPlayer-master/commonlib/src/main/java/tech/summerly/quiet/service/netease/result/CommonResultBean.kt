package tech.summerly.quiet.service.netease.result

/**
 * Created by Summerly on 2017/10/2.
 * Desc:
 */
class CommonResultBean(val code: Int)