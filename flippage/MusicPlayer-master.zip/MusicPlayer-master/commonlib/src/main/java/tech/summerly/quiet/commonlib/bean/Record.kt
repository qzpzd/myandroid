package tech.summerly.quiet.commonlib.bean

/**
 * Created by summer on 18-2-27
 */
data class Record(val playCount: Int,
                  val score: Int,
                  val music: Music)