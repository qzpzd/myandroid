package tech.summerly.quiet.local

import tech.summerly.quiet.commonlib.base.BaseModule

/**
 * author : yangbin10
 * date   : 2018/1/15
 */
object LocalModule : BaseModule() {


    override fun onCreate() {
    }
}