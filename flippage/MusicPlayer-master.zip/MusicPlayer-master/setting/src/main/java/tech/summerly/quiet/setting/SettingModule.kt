package tech.summerly.quiet.setting

import tech.summerly.quiet.commonlib.base.BaseModule

/**
 * Created by summer on 18-2-12
 */
internal object SettingModule : BaseModule() {

    override fun onCreate() {
        super.onCreate()
    }
}